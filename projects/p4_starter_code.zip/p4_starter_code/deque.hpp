#ifndef DEQUE_HPP
#define DEQUE_HPP

#include "abstract_deque.hpp"

template <typename T>
class Deque: public AbstractDeque<T>{

  // TODO
  
};

#include "deque.tpp"

#endif
